#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "volunteer.h"
#include "read_line.h"

struct volunteer *add_to_list(struct volunteer *list) {
    struct volunteer *new_user = malloc(sizeof(struct volunteer));
    if (new_user == NULL) {
        printf("Memory allocation failed.\n");
        return list;
    }

    // Input volunteer information
    printf("Enter last name: ");
    read_line(new_user->last, NAME_LEN);

    printf("Enter first name: ");
    read_line(new_user->first, NAME_LEN);

    printf("Enter email address: ");
    read_line(new_user->email, EMAIL_LEN);

    printf("Enter grade level: ");
    char grade_input[10]; // Assuming grade level input will not exceed 10 characters
    read_line(grade_input, 10);
    new_user->grade_level = atoi(grade_input); // Convert string to integer

    // Check for duplicate entry
    if (is_duplicate(list, new_user) == 0) {
        new_user->next = NULL;
        if (list == NULL) {
            return new_user;
        }
        struct volunteer *temp = list;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = new_user;
        return list;
    }
    printf("Volunteer already exists.\n");
    free(new_user);
    return list;
}

// Function to check if a volunteer already exists in the list
int is_duplicate(struct volunteer *list, struct volunteer *new_user) {
    struct volunteer *temp = list;
    if (list == NULL) {
        return 0;
    }
    while (temp != NULL) {
        if (strcmp(temp->last, new_user->last) == 0 && strcmp(temp->email, new_user->email) == 0) {
            return 1;
        }
        temp = temp->next;
    }
    return 0;
}

struct volunteer *delete_node(struct volunteer *list) {
    char last_name[NAME_LEN + 1];
    char first_name[NAME_LEN + 1];
    char email[EMAIL_LEN + 1];
    int grade;

    // Prompting user for input
    printf("Enter last name: ");
    read_line(last_name, NAME_LEN);

    printf("Enter first name: ");
    read_line(first_name, NAME_LEN);

    printf("Enter email address: ");
    read_line(email, EMAIL_LEN);

    printf("Enter grade level: ");
    char grade_input[10]; // Assuming grade level input will not exceed 10 characters
    read_line(grade_input, 10);
    grade = atoi(grade_input); // Convert string to integer

    // Initializing current and previous pointers
    struct volunteer *curr = list;
    struct volunteer *prev = NULL;

    // Looping through the list to find the node to delete
    for (; curr != NULL && !(strcmp(curr->last, last_name) == 0 && strcmp(curr->first, first_name) == 0 && strcmp(curr->email, email) == 0 && (curr->grade_level == grade)); prev = curr, curr = curr->next);

    // If the node is not found
    if (curr == NULL) {
        printf("Volunteer does not exist.\n");
        return list;
    }

    // Deleting the node
    if (prev == NULL) {
        // Deleting the first node
        list = curr->next;
    } else {
        prev->next = curr->next;
    }
    free(curr);
    return list;
}

// Function to search for volunteers by grade level
void search_list(struct volunteer *list) {
    int grade;
    printf("Enter grade level: ");
    scanf("%d", &grade);
    struct volunteer *temp = list;
    int found = 0;
    if (list == NULL) {
        return;
    }
    while (temp != NULL) {
        if (temp->grade_level == grade) {
            printf("%-12s%-12s%-30s\n", temp->last, temp->first, temp->email);
            found = 1;
        }
        temp = temp->next;
    }
    if (!found) {
        printf("Not found\n");
    }
}

// Function to print the list of volunteers
void print_list(struct volunteer *list) {
    struct volunteer *temp = list;
    if (list == NULL) {
        return;
    }
    while (temp != NULL) {
        printf("%-12s%-12s%-30s%5d\n", temp->last, temp->first, temp->email, temp->grade_level);
        temp = temp->next;
    }
}

// Function to clear the list and free memory
void clear_list(struct volunteer *list) {
    struct volunteer *current = list;
    struct volunteer *next;
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    list = NULL;
}
