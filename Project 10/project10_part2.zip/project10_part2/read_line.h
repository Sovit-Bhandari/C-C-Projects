#ifndef read_line_h
#define read_line_h

// Function prototype for reading a line of input
int read_line(char str[], int n);

#endif // End of read_line_h
