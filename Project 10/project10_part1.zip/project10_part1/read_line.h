
#ifndef read_line_h
#define read_line_h

int read_line(char str[], int n);
#endif