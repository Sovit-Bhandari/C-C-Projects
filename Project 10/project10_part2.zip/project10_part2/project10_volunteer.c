/*
Name = Sovit Bhandari
U-Id= U83561265
Discription = This C program manages a list of volunteers using dynamic memory allocation. It presents users with options to add, search, delete, or print
 volunteers from the list. The main function initializes an empty volunteer list and enters an interactive loop to receive and execute user commands.
  Functions like add_to_list, search_list, delete_node, and print_list handle respective operations on the list. The program ensures memory cleanup upon
   quitting.
*/

#include <stdio.h>
#include "volunteer.h"

// Main function
int main(void) {
    // Declaration of variables
    char code;                                                                                          // Operation code
    struct volunteer *volunteer_list = NULL;                                                            // Pointer to the head of the volunteer list

    // Print the instructions for the user
    printf("Operation Code: a for adding to the list, s for searching, d for deleting from the list, p for printing the list; q for quit.\n");

    // Infinite loop to keep the program running until 'q' (quit) is entered
    for (;;) {
                                                                                                        // Prompt the user to enter an operation code
        printf("Enter operation code: ");
        scanf(" %c", &code);                                                                            // Read the operation code from the user
        while (getchar() != '\n');                                                                      // Clear the input buffer

        // Switch statement to perform different actions based on the operation code entered by the user
        switch (code) {
            case 'a':
                volunteer_list = add_to_list(volunteer_list);                                           // Add a volunteer to the list
                break;
            case 's':
                search_list(volunteer_list);                                                            // Search for volunteers by grade level
                break;
            case 'd':
                volunteer_list = delete_node(volunteer_list);                                           // Delete a volunteer from the list
                break;
            case 'p':
                print_list(volunteer_list);                                                             // Print the list of volunteers
                break;
            case 'q':
                clear_list(volunteer_list);                                                             // Clear the list and free memory
                return 0;                                                                               // Exit the program
            default:
                printf("Illegal code\n");                                                               // If an invalid operation code is entered, print a message
        }
        printf("\n");                                                                                   // Print a newline for better readability after each operation
    }
}
