#ifndef VOLUNTEER_H
#define VOLUNTEER_H

// Define maximum lengths for email and name fields
#define EMAIL_LEN 100
#define NAME_LEN 30

// Define a structure to represent a volunteer
struct volunteer {
    char first[NAME_LEN + 1];                                                                           // First name of the volunteer
    char last[NAME_LEN + 1];                                                                            // Last name of the volunteer
    char email[EMAIL_LEN + 1];                                                                          // Email address of the volunteer
    int grade_level;                                                                                    // Grade level of the volunteer
    struct volunteer *next;                                                                             // Pointer to the next volunteer in the list
};

// Function prototypes for volunteer management
struct volunteer *add_to_list(struct volunteer *list);                                                  // Add a volunteer to the list
void search_list(struct volunteer *list);                                                               // Search for volunteers by grade level
void print_list(struct volunteer *list);                                                                // Print the list of volunteers
void clear_list(struct volunteer *list);                                                                // Clear the list and free memory
struct volunteer *delete_node(struct volunteer *list);                                                  // Delete a volunteer from the list
int is_duplicate(struct volunteer *list, struct volunteer *new_user);                                   // Check for duplicate volunteers

#endif                                                                                                  // End of VOLUNTEER_H
