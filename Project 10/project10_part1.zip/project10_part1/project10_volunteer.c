#include <stdio.h>
#include "volunteer.h" // Include the volunteer header file

int main(void) {
    char code;
    struct volunteer *volunteer_list = NULL;

    // Display operation codes
    printf("Operation Code: a for adding to the list, s for searching, d for deleting from the list, p for printing the list; q for quit.\n");

    // Infinite loop to interact with the user
    for (;;) {
        printf("Enter operation code: ");
        scanf(" %c", &code);
        while (getchar() != '\n'); // Skip to end of line

        // Switch statement to execute user's choice
        switch (code) {
            case 'a':
                volunteer_list = add_to_list(volunteer_list);
                break;
            case 's':
                search_list(volunteer_list);
                break;

            case 'd':
                volunteer_list = delete_node(volunteer_list); // Change function call
                break;
            case 'p':
                print_list(volunteer_list);
                break;
            case 'q':
                clear_list(volunteer_list);
                return 0;
            default:
                printf("Illegal code\n");
        }
        printf("\n");
    }
}
