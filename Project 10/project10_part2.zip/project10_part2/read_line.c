#include <ctype.h>
#include <stdio.h>

// Function to read a line from input with specified maximum length
int read_line(char str[], int n) {
    int ch, i = 0;
    while (isspace(ch = getchar()));                                                                            // Skip leading whitespace characters
    str[i++] = ch;                                                                                              // Store the first non-whitespace character
    while ((ch = getchar()) != '\n') {                                                                          // Read characters until newline
        if (i < n)                                                                                              // Check if within maximum length
            str[i++] = ch;                                                                                      // Store character in the string
    }                                                               
    str[i] = '\0';                                                                                              // Null-terminate the string
    return i;                                                                                                   // Return the length of the string
}
