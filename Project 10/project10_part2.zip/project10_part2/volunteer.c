#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "volunteer.h"
#include "read_line.h"

// Define a structure for volunteer information
struct volunteer *add_to_list(struct volunteer *list) {
    // Allocate memory for a new volunteer
    struct volunteer *new_user = malloc(sizeof(struct volunteer));
    // Check if memory allocation was successful
    if (new_user == NULL) {
        printf("Memory allocation failed.\n");
        return list;
    }

    // Prompt for and read the last name
    printf("Enter last name: ");
    fgets(new_user->last, NAME_LEN + 1, stdin);
    new_user->last[strcspn(new_user->last, "\n")] = '\0';

    // Prompt for and read the first name
    printf("Enter first name: ");
    fgets(new_user->first, NAME_LEN + 1, stdin);
    new_user->first[strcspn(new_user->first, "\n")] = '\0'; 

    // Prompt for and read the email address
    printf("Enter email address: ");
    fgets(new_user->email, EMAIL_LEN + 1, stdin);
    new_user->email[strcspn(new_user->email, "\n")] = '\0'; 

    // Prompt for and read the grade level
    printf("Enter grade level: ");
    char grade_input[10]; 
    fgets(grade_input, 10, stdin);
    new_user->grade_level = atoi(grade_input);

    // Check if the volunteer is a duplicate
    if (is_duplicate(list, new_user) == 0) {
        new_user->next = NULL;
        // If the list is empty, return the new volunteer as the first element
        if (list == NULL) {
            return new_user;
        }
        // Otherwise, add the new volunteer to the end of the list
        struct volunteer *temp = list;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = new_user;
        return list;
    }
    // If the volunteer is a duplicate, free the memory and return the original list
    printf("volunteer already exists.\n");
    free(new_user);
    return list;
}

// Check if a volunteer already exists in the list
int is_duplicate(struct volunteer *list, struct volunteer *new_user) {
    struct volunteer *temp = list;
    // If the list is empty, return false
    if (list == NULL) {
        return 0;
    }
    // Iterate through the list and compare last name and email address
    while (temp != NULL) {
        if (strcmp(temp->last, new_user->last) == 0 && strcmp(temp->email, new_user->email) == 0) {
            return 1; // If a duplicate is found, return true
        }
        temp = temp->next;
    }
    return 0; // If no duplicates are found, return false
}

// Delete a volunteer node from the list
struct volunteer *delete_node(struct volunteer *list) {
    char last_name[NAME_LEN + 1];
    char first_name[NAME_LEN + 1];
    char email[EMAIL_LEN + 1];
    int grade;

    // Prompt for and read the volunteer's information to delete
    printf("Enter last name: ");
    scanf("%s", last_name);

    printf("Enter first name: ");
    scanf("%s", first_name);

    printf("Enter email address: ");
    scanf("%s", email);

    printf("Enter grade level: ");
    scanf("%d", &grade);

    // Initialize current and previous pointers for traversal
    struct volunteer *curr = list;
    struct volunteer *prev = NULL;

    // Traverse the list to find the volunteer to delete
    for (; curr != NULL && !(strcmp(curr->last, last_name) == 0 && strcmp(curr->first, first_name) == 0 && strcmp(curr->email, email) == 0 && (curr->grade_level == grade)); prev = curr, curr = curr->next);

    // If the volunteer is not found, print a message and return the original list
    if (curr == NULL) {
        printf("volunteer does not exist\n");
        return list;
    }

    // If the volunteer to delete is the first node
    if (prev == NULL) {
        list = curr->next;
    } else {
        // If the volunteer to delete is not the first node
        prev->next = curr->next;
    }
    // Free memory for the deleted volunteer
    free(curr);
    return list;
}

// Search for volunteers by grade level
void search_list(struct volunteer *list) {
    int grade;
    printf("Enter grade level: ");
    scanf("%d", &grade);
    struct volunteer *temp = list;
    int found = 0;
    // If the list is empty, return
    if (list == NULL) {
        return;
    }
    // Iterate through the list to find volunteers with the specified grade level
    while (temp != NULL) {
        if (temp->grade_level == grade) {
            printf("%-12s%-12s%-30s\n", temp->last, temp->first, temp->email);
            found = 1;
        }
        temp = temp->next;
    }
    // If no volunteers are found with the specified grade level, print a message
    if (!found) {
        printf(" not found\n");
    }
}

// Print the entire list of volunteers
void print_list(struct volunteer *list) {
    struct volunteer *temp = list;
    // If the list is empty, return
    if (list == NULL) {
        return;
    }
    // Iterate through the list and print each volunteer's information
    while (temp != NULL) {
        printf("%-12s%-12s%-30s%5d\n", temp->last, temp->first, temp->email, temp->grade_level);
        temp = temp->next;
    }
}

// Clear the entire list and free memory
void clear_list(struct volunteer *list) {
    struct volunteer *current = list;
    struct volunteer *next;
    // Iterate through the list and free memory for each node
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    list = NULL; // Set the list pointer to NULL after clearing the list
}
